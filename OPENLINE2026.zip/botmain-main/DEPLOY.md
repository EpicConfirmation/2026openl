# 🚀 Deploy "Ball Supplies" Bot on Railway (bot + MongoDB, all on Railway)

Everything runs on Railway: the Python bot **and** the database. No Atlas, no passwords to
build by hand. The bot's code auto-builds the Mongo connection from Railway's variables.

---

## Step 1 — Push code to GitHub
In the Emergent chat, click **Save to GitHub** → push to a repo (e.g. `ball-supplies-bot`).
Confirm the repo has: `railway.json`, `nixpacks.toml`, `requirements.txt`, `backend/telegram_bot.py`.

## Step 2 — Create the Railway project + deploy the bot
1. Go to https://railway.app → log in with GitHub.
2. **New Project → Deploy from GitHub repo** → pick your repo → **Deploy**.
3. It builds via `railway.json` (Nixpacks) and starts the worker. It will error about
   `MONGO_URL` until Step 4 — that's expected.

## Step 3 — Add MongoDB (on Railway)
1. In the project canvas: **+ Create → Database → Add MongoDB**.
2. Wait until the MongoDB service is green/Active.

## Step 4 — Wire the database into the BOT service (the reliable way)
On your **bot service → Variables**, add these. For the four `MONGO*` ones, use
**“Add Reference”** (or type `${{` and pick from the dropdown) and select your **MongoDB**
service's matching variable — this guarantees they resolve to real values:

```
TELEGRAM_BOT_TOKEN = <your token from @BotFather>
DB_NAME            = ball_supplies
MONGOHOST          = ${{<MongoDB service>.MONGOHOST}}
MONGOPORT          = ${{<MongoDB service>.MONGOPORT}}
MONGOUSER          = ${{<MongoDB service>.MONGOUSER}}
MONGOPASSWORD      = ${{<MongoDB service>.MONGOPASSWORD}}
BTC_ADDRESS        = bc1qw2cvwvscfdy35mce8qhryv7fjyyspqyzcq8m44
LTC_ADDRESS        = ltc1qkp0d6f0tzjnqe3v3zr2q0gxptmqtypxrt6mpt9
```

> The bot builds the Mongo URL from `MONGOUSER/MONGOPASSWORD/MONGOHOST/MONGOPORT`
> automatically, so you never have to assemble the connection string yourself.
>
> Alternative (also supported): set a single `MONGO_URL` as a reference to your MongoDB
> service's **`MONGO_PUBLIC_URL`**. If you use this, you can skip the four `MONGO*` vars.

Click **Save** → the bot redeploys.

## Step 5 — Confirm it's live
Bot service → **Deployments → View Logs**. You want:
```
✅ MongoDB connection OK (db=ball_supplies)
Ball Supplies bot ready. Admins: {'fleetosan'}
Application started
```
Open Telegram → message **@BallSuppliesBot** → `/start`. It replies. 🎉

---

## ⚠️ Must-dos
- **Only ONE bot instance** may run with your token. Delete/stop any other Railway project
  or service that runs this bot (two instances → `Conflict` errors → no replies).
- **Replicas = 1**: bot service → Settings → Deploy → Replicas = 1.
- **Builder = Nixpacks**, **no custom build command** (leave it empty so it auto-installs
  `requirements.txt`). Start command is set by `railway.json`:
  `python backend/telegram_bot.py`.

## Variables the bot understands (any one of these works for the DB)
- `MONGO_URL` (full URI), or
- `MONGO_PUBLIC_URL`, or
- the four parts `MONGOUSER` / `MONGOPASSWORD` / `MONGOHOST` / `MONGOPORT`
`DB_NAME` defaults to `ball_supplies` if not set.
