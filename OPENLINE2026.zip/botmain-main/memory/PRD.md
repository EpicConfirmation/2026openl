# Ball Supplies — Telegram Bot

## Problem Statement
Telegram shop bot rebranded to "✨ Ball Supplies ✨" with in-Telegram admin panel:
nested categories add/remove, product add/remove (name, price, desc, photo, stock),
review add/remove (1-5 stars, no name), FAQ, cart + crypto checkout (BTC/LTC),
live support chat (close + download transcript), and postcode+name order tracking.
No admin username shown anywhere to customers. Runs 24/7 via supervisor.

## Architecture
- **Bot**: python-telegram-bot 21.10 (async, long-polling) + JobQueue (APScheduler) for
  auto payment polling. Runs as supervisor program `telegrambot` (autostart/autorestart).
- **Storage**: MongoDB (motor) — categories(+parent_id), products, reviews, carts, orders,
  settings, admin_chats, tracking, support_sessions.
- **Crypto**: GBP->BTC/LTC via CoinGecko simple/price; on-chain verification via Esplora
  (blockstream.info for BTC, litecoinspace.org for LTC). Unique-amount technique
  (base amount + random 1-9999 sats) to match a specific order to a deposit; tolerance 2 sats,
  time-window guard vs old deposits. Auto-confirm poller every 120s + on-demand "Check Payment".
- **File**: `/app/backend/telegram_bot.py`. Config in `.env`: TELEGRAM_BOT_TOKEN,
  ADMIN_USERNAMES, BTC_ADDRESS, LTC_ADDRESS.
- Bot: @BallSuppliesBot.

## Implemented (2026-06-24)
- Rebrand to Ball Supplies; main menu shows "Open a support chat for inquiries" (no @username).
- Nested categories (category-in-category) with recursive delete; browse drills into sub-cats.
- Cart + checkout collects delivery details -> choose BTC/LTC -> live invoice with exact amount
  + address -> "I've Paid" verify / auto-poll confirm -> notifies customer + admins, decrements stock.
- Live support chat: customer<->admin relay, admin "Reply" button per message, Close Chat,
  Download Chat (.txt transcript). Sessions persisted.
- Track Order: customer enters name + postcode, returns admin-set tracking number(s).
- Admin panel: add/remove (nested) category, add/remove product, add/remove review,
  add/remove tracking, edit FAQ, view orders (with payment status).
- Verified: CoinGecko live price OK; Esplora BTC/LTC queries OK (LTC addr has 12 real txs);
  verify_payment, recursive delete, tracking search, nested categories smoke-tested.

## Admin
- Admin = Telegram username in ADMIN_USERNAMES (`FleetoSan`). Not displayed to customers.

## Backlog / Next
- P1: QR code image for the crypto address on the invoice.
- P2: Order status push to customer when admin marks shipped; expire stale unpaid orders + restock.
- P2: Editable Sales counter & multi-admin management from the panel.
- P2: Deploy for permanent 24/7 (preview runs while pod is active).
