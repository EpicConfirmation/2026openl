"""
✨ Ball Supplies ✨ — Telegram store bot
Storefront (nested categories, cart, BTC/LTC checkout) + live support chat
+ order tracking + in-Telegram admin panel.

Database: SQLite — MongoDB is NOT required.
"""

import os
import re
import uuid
import random
import logging
import sqlite3
import json
import asyncio

from io import BytesIO
from pathlib import Path
from decimal import Decimal, ROUND_UP
from datetime import datetime, timezone, timedelta

import httpx
from dotenv import load_dotenv

from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InputFile,
)

from telegram.constants import ParseMode

from telegram.ext import (
    Application,
    ApplicationBuilder,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    Defaults,
    MessageHandler,
    filters,
)


# ===========================================================================
# CONFIG
# ===========================================================================

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)

logger = logging.getLogger("ballsupplies")
logging.getLogger("httpx").setLevel(logging.WARNING)


# Set BOT_TOKEN in Railway/GitHub environment variables.
TOKEN = os.environ.get("BOT_TOKEN", "").strip()

if not TOKEN:
    raise RuntimeError(
        "BOT_TOKEN is missing. Add your new Telegram bot token as the BOT_TOKEN environment variable."
    )

    raise SystemExit(
        "BOT_TOKEN is missing. Add your new Telegram bot token as the "
        "BOT_TOKEN environment variable."
    )


ADMIN_USERNAMES = {
    u.strip().lstrip("@").lower()
    for u in os.environ.get("ADMIN_USERNAMES", "").split(",")
    if u.strip()
}


BTC_ADDRESS = os.environ.get("BTC_ADDRESS", "").strip()
LTC_ADDRESS = os.environ.get("LTC_ADDRESS", "").strip()

if not BTC_ADDRESS:
    raise SystemExit("BTC_ADDRESS is missing.")

if not LTC_ADDRESS:
    raise SystemExit("LTC_ADDRESS is missing.")


SHOP_NAME = "Ball Supplies"

COINGECKO_URL = "https://api.coingecko.com/api/v3/simple/price"

ESPLORA_URL = {
    "BTC": "https://blockstream.info/api/address/{addr}/txs",
    "LTC": "https://litecoinspace.org/api/address/{addr}/txs",
}

COIN_IDS = {
    "BTC": "bitcoin",
    "LTC": "litecoin",
}

COIN_ADDR = {
    "BTC": BTC_ADDRESS,
    "LTC": LTC_ADDRESS,
}


# ===========================================================================
# SQLITE DATABASE
# ===========================================================================

DB_PATH = ROOT_DIR / "ball_supplies.db"


class SQLiteResult:
    def __init__(
        self,
        inserted_id=None,
        modified_count=0,
        deleted_count=0,
    ):
        self.inserted_id = inserted_id
        self.modified_count = modified_count
        self.deleted_count = deleted_count


class SQLiteCursor:
    def __init__(
        self,
        collection,
        query=None,
        projection=None,
    ):
        self.collection = collection
        self.query = query or {}
        self.projection = projection
        self._sort_field = None
        self._sort_direction = 1

    def sort(self, field, direction=1):
        self._sort_field = field
        self._sort_direction = direction
        return self

    async def to_list(self, length=None):
        return await self.collection._find_many(
            self.query,
            self.projection,
            self._sort_field,
            self._sort_direction,
            length,
        )


class SQLiteCollection:
    """
    Small Mongo-like wrapper around SQLite.

    This lets the rest of the bot continue using familiar methods:
      find_one()
      find()
      insert_one()
      update_one()
      delete_one()
      delete_many()
    """

    def __init__(self, database, name):
        self.database = database
        self.name = name

    async def find_one(self, query=None, projection=None):
        docs = await self._find_many(
            query or {},
            projection,
            None,
            1,
            1,
        )

        return docs[0] if docs else None

    def find(self, query=None, projection=None):
        return SQLiteCursor(
            self,
            query or {},
            projection,
        )

    async def insert_one(self, document):
        doc = dict(document)

        if "_id" not in doc:
            doc["_id"] = uuid.uuid4().hex

        await self.database._insert(
            self.name,
            doc,
        )

        return SQLiteResult(
            inserted_id=doc["_id"]
        )

    async def update_one(
        self,
        query,
        update,
        upsert=False,
    ):
        existing = await self.find_one(query)

        if existing:
            updated = dict(existing)

            # $set
            if "$set" in update:
                for key, value in update["$set"].items():
                    updated[key] = value

            # $inc
            if "$inc" in update:
                for key, value in update["$inc"].items():
                    updated[key] = updated.get(key, 0) + value

            # $push
            if "$push" in update:
                for key, value in update["$push"].items():
                    arr = updated.get(key, [])

                    if not isinstance(arr, list):
                        arr = []

                    arr.append(value)
                    updated[key] = arr

            await self.database._replace(
                self.name,
                updated,
            )

            return SQLiteResult(
                modified_count=1
            )

        if not upsert:
            return SQLiteResult()

        # Build a new document for upsert.
        new_doc = {}

        for key, value in query.items():
            if not key.startswith("$"):
                new_doc[key] = value

        if "$set" in update:
            for key, value in update["$set"].items():
                new_doc[key] = value

        if "$inc" in update:
            for key, value in update["$inc"].items():
                new_doc[key] = value

        if "$push" in update:
            for key, value in update["$push"].items():
                new_doc[key] = [value]

        if "_id" not in new_doc:
            new_doc["_id"] = uuid.uuid4().hex

        await self.database._insert(
            self.name,
            new_doc,
        )

        return SQLiteResult(
            inserted_id=new_doc["_id"]
        )

    async def delete_one(self, query):
        docs = await self._find_many(
            query,
            None,
            None,
            1,
            1,
        )

        if not docs:
            return SQLiteResult()

        await self.database._delete(
            self.name,
            docs[0]["_id"],
        )

        return SQLiteResult(
            deleted_count=1
        )

    async def delete_many(self, query):
        docs = await self._find_many(query)

        for doc in docs:
            await self.database._delete(
                self.name,
                doc["_id"],
            )

        return SQLiteResult(
            deleted_count=len(docs)
        )

    async def _find_many(
        self,
        query,
        projection=None,
        sort_field=None,
        sort_direction=1,
        length=None,
    ):
        return await self.database._find(
            self.name,
            query,
            projection,
            sort_field,
            sort_direction,
            length,
        )


class SQLiteDatabase:
    def __init__(self, path):
        self.path = str(path)
        self._init_db()

    def _connect(self):
        conn = sqlite3.connect(
            self.path,
            timeout=30,
        )

        conn.row_factory = sqlite3.Row

        return conn

    def _init_db(self):
        conn = self._connect()

        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS documents (
                collection TEXT NOT NULL,
                id TEXT NOT NULL,
                data TEXT NOT NULL,
                PRIMARY KEY (collection, id)
            )
            """
        )

        conn.commit()
        conn.close()

    async def _run(self, func, *args):
        return await asyncio.to_thread(
            func,
            *args,
        )

    def _insert_sync(
        self,
        collection,
        document,
    ):
        conn = self._connect()

        conn.execute(
            """
            INSERT OR REPLACE INTO documents
            (collection, id, data)
            VALUES (?, ?, ?)
            """,
            (
                collection,
                document["_id"],
                json.dumps(
                    document,
                    ensure_ascii=False,
                ),
            ),
        )

        conn.commit()
        conn.close()

    async def _insert(
        self,
        collection,
        document,
    ):
        await self._run(
            self._insert_sync,
            collection,
            document,
        )

    def _replace_sync(
        self,
        collection,
        document,
    ):
        conn = self._connect()

        conn.execute(
            """
            UPDATE documents
            SET data = ?
            WHERE collection = ? AND id = ?
            """,
            (
                json.dumps(
                    document,
                    ensure_ascii=False,
                ),
                collection,
                document["_id"],
            ),
        )

        conn.commit()
        conn.close()

    async def _replace(
        self,
        collection,
        document,
    ):
        await self._run(
            self._replace_sync,
            collection,
            document,
        )

    def _delete_sync(
        self,
        collection,
        doc_id,
    ):
        conn = self._connect()

        conn.execute(
            """
            DELETE FROM documents
            WHERE collection = ? AND id = ?
            """,
            (
                collection,
                doc_id,
            ),
        )

        conn.commit()
        conn.close()

    async def _delete(
        self,
        collection,
        doc_id,
    ):
        await self._run(
            self._delete_sync,
            collection,
            doc_id,
        )

    def _find_sync(
        self,
        collection,
        query,
        projection,
        sort_field,
        sort_direction,
        length,
    ):
        conn = self._connect()

        rows = conn.execute(
            """
            SELECT data
            FROM documents
            WHERE collection = ?
            """,
            (collection,),
        ).fetchall()

        conn.close()

        docs = []

        for row in rows:
            try:
                doc = json.loads(row["data"])
            except Exception:
                continue

            if self._matches(
                doc,
                query,
            ):
                if projection:
                    doc = self._apply_projection(
                        doc,
                        projection,
                    )

                docs.append(doc)

        if sort_field:
            docs.sort(
                key=lambda x: x.get(
                    sort_field,
                    "",
                ),
                reverse=sort_direction < 0,
            )

        if length is not None:
            docs = docs[:length]

        return docs

    async def _find(
        self,
        collection,
        query,
        projection=None,
        sort_field=None,
        sort_direction=1,
        length=None,
    ):
        return await self._run(
            self._find_sync,
            collection,
            query,
            projection,
            sort_field,
            sort_direction,
            length,
        )

    @staticmethod
    def _matches(
        doc,
        query,
    ):
        for key, expected in query.items():
            actual = doc.get(key)

            if isinstance(expected, dict):
                for operator, value in expected.items():

                    if operator == "$gte":
                        if actual is None or actual < value:
                            return False

                    elif operator == "$gt":
                        if actual is None or actual <= value:
                            return False

                    elif operator == "$lte":
                        if actual is None or actual > value:
                            return False

                    elif operator == "$lt":
                        if actual is None or actual >= value:
                            return False

                    elif operator == "$ne":
                        if actual == value:
                            return False

                    else:
                        return False

            else:
                if actual != expected:
                    return False

        return True

    @staticmethod
    def _apply_projection(
        doc,
        projection,
    ):
        include = [
            key
            for key, value in projection.items()
            if value and key != "_id"
        ]

        if not include:
            return doc

        result = {}

        for key in include:
            if key in doc:
                result[key] = doc[key]

        if projection.get(
            "_id",
            1,
        ) and "_id" in doc:
            result["_id"] = doc["_id"]

        return result


sqlite_db = SQLiteDatabase(DB_PATH)

categories = SQLiteCollection(
    sqlite_db,
    "categories",
)

products = SQLiteCollection(
    sqlite_db,
    "products",
)

reviews = SQLiteCollection(
    sqlite_db,
    "reviews",
)

carts = SQLiteCollection(
    sqlite_db,
    "carts",
)

orders = SQLiteCollection(
    sqlite_db,
    "orders",
)

settings = SQLiteCollection(
    sqlite_db,
    "settings",
)

admin_chats = SQLiteCollection(
    sqlite_db,
    "admin_chats",
)

tracking = SQLiteCollection(
    sqlite_db,
    "tracking",
)

support = SQLiteCollection(
    sqlite_db,
    "support_sessions",
)


# ===========================================================================
# FAQ
# ===========================================================================

DEFAULT_FAQ = (
    "📖 <b>Frequently Asked Questions</b>\n\n"
    "<b>1. When do you ship?</b>\n"
    "We ship Monday–Friday. Cut-off for same-day dispatch is 2PM.\n\n"
    "<b>2. Where do you ship from / to?</b>\n"
    "Ships from the UK to UK / EU / US.\n\n"
    "<b>3. How do I pay?</b>\n"
    "We accept Bitcoin (BTC) and Litecoin (LTC). At checkout you'll get the exact amount "
    "and address — pay the exact amount, then tap “I've Paid”.\n\n"
    "<b>4. How long does delivery take?</b>\n"
    "UK 1–3 working days. EU/US times vary.\n\n"
    "<b>5. How do I track my order?</b>\n"
    "Use the 🚚 Track Order button and enter your name + postcode.\n\n"
    "<b>6. Need more help?</b>\n"
    "Use the 💬 Support Chat to talk to our team directly."
)


# ===========================================================================
# HELPERS
# ===========================================================================

def now_iso():
    return datetime.now(
        timezone.utc
    ).isoformat()


def gen_id():
    return uuid.uuid4().hex[:16]


async def get_setting(
    key,
    default=None,
):
    doc = await settings.find_one(
        {"key": key}
    )

    return (
        doc["value"]
        if doc
        else default
    )


async def set_setting(
    key,
    value,
):
    await settings.update_one(
        {"key": key},
        {"$set": {"value": value}},
        upsert=True,
    )


async def rating_summary():
    docs = await reviews.find(
        {},
        {"stars": 1},
    ).to_list(10000)

    if not docs:
        return "4.94", 164

    total = sum(
        d.get("stars", 0)
        for d in docs
    )

    return (
        f"{total / len(docs):.2f}",
        len(docs),
    )


def is_admin(
    update: Update,
) -> bool:
    user = update.effective_user

    return bool(
        user
        and user.username
        and user.username.lower()
        in ADMIN_USERNAMES
    )


async def track_admin(
    update: Update,
):
    if is_admin(update):
        await admin_chats.update_one(
            {
                "username":
                    update.effective_user.username.lower()
            },
            {
                "$set": {
                    "chat_id":
                        update.effective_chat.id
                }
            },
            upsert=True,
        )


async def admin_chat_ids():
    return [
        a["chat_id"]
        async for a in admin_chats.find()
    ]


# ===========================================================================
# RENDERING
# ===========================================================================

async def render(
    update,
    context,
    text,
    keyboard=None,
    photo=None,
):
    chat_id = update.effective_chat.id
    query = update.callback_query

    if query is not None:
        try:
            await query.message.delete()
        except Exception:
            pass

    if photo:
        await context.bot.send_photo(
            chat_id,
            photo=photo,
            caption=text,
            reply_markup=keyboard,
        )
    else:
        await context.bot.send_message(
            chat_id,
            text=text,
            reply_markup=keyboard,
            disable_web_page_preview=True,
        )


def _back_kb(
    cb="menu:main",
    label="⬅ Back to Menu",
):
    return InlineKeyboardMarkup(
        [[
            InlineKeyboardButton(
                label,
                callback_data=cb,
            )
        ]]
    )


def admin_back_kb():
    return InlineKeyboardMarkup(
        [[
            InlineKeyboardButton(
                "⬅ Admin Panel",
                callback_data="admin:panel",
            )
        ]]
    )


async def main_menu_text():
    avg, count = await rating_summary()

    sales = int(
        await get_setting(
            "sales",
            984,
        )
        or 984
    )

    return (
        f"✨ <b>{SHOP_NAME}</b> ✨\n"
        "━━━━━━━━━━━━━━━\n"
        "🕐 Last seen: recently\n"
        "📦 Ships from: UK → UK/EU/US\n"
        f"💰 Sales: {sales}\n"
        "💷 Currency: GBP\n"
        f"⭐️ Rating: ★{avg} ({count})\n\n"
        "📅 We ship Monday–Friday. Cut-off for same-day dispatch is 2PM.\n\n"
        "📖 Please refer to the FAQ first for any questions — you should find the answers there.\n\n"
        "💬 Open a support chat for inquiries."
    )


def main_menu_keyboard(
    admin: bool,
):
    rows = [
        [
            InlineKeyboardButton(
                "🛍 Browse Categories",
                callback_data="menu:categories",
            )
        ],
        [
            InlineKeyboardButton(
                "🛒 My Cart",
                callback_data="cart:view",
            ),
            InlineKeyboardButton(
                "⭐️ Reviews",
                callback_data="menu:reviews",
            ),
        ],
        [
            InlineKeyboardButton(
                "🚚 Track Order",
                callback_data="track:start",
            ),
            InlineKeyboardButton(
                "📖 FAQ",
                callback_data="menu:faq",
            ),
        ],
        [
            InlineKeyboardButton(
                "💬 Support Chat",
                callback_data="sup:open",
            )
        ],
    ]

    if admin:
        rows.append(
            [
                InlineKeyboardButton(
                    "👑 Admin Panel",
                    callback_data="admin:panel",
                )
            ]
        )

    return InlineKeyboardMarkup(rows)


async def show_main_menu(
    update,
    context,
):
    context.user_data.pop(
        "flow",
        None,
    )

    await render(
        update,
        context,
        await main_menu_text(),
        main_menu_keyboard(
            is_admin(update)
        ),
    )


# ===========================================================================
# COMMANDS
# ===========================================================================

async def start(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    await track_admin(update)
    await show_main_menu(
        update,
        context,
    )


async def cancel(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    context.user_data.pop(
        "flow",
        None,
    )

    await update.message.reply_text(
        "❌ Cancelled."
    )

    await context.bot.send_message(
        update.effective_chat.id,
        await main_menu_text(),
        reply_markup=main_menu_keyboard(
            is_admin(update)
        ),
    )


async def back(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    context.user_data.pop(
        "flow",
        None,
    )

    context.user_data.pop(
        "support",
        None,
    )

    await context.bot.send_message(
        update.effective_chat.id,
        await main_menu_text(),
        reply_markup=main_menu_keyboard(
            is_admin(update)
        ),
    )


# ===========================================================================
# CATALOG
# ===========================================================================

async def show_categories(
    update,
    context,
):
    cats = await categories.find(
        {"parent_id": None}
    ).sort(
        "name",
        1,
    ).to_list(1000)

    rows = []

    if not cats:
        text = (
            "🛍 <b>Categories</b>\n\n"
            "No categories yet. Please check back soon!"
        )
    else:
        text = (
            "🛍 <b>Browse Categories</b>\n\n"
            "Select a category:"
        )

        for c in cats:
            rows.append(
                [
                    InlineKeyboardButton(
                        f"📂 {c['name']}",
                        callback_data=f"cat:{c['id']}",
                    )
                ]
            )

    rows.append(
        [
            InlineKeyboardButton(
                "⬅ Back to Menu",
                callback_data="menu:main",
            )
        ]
    )

    await render(
        update,
        context,
        text,
        InlineKeyboardMarkup(rows),
    )


async def show_category(
    update,
    context,
    cat_id,
):
    cat = await categories.find_one(
        {"id": cat_id}
    )

    if not cat:
        await render(
            update,
            context,
            "Category not found.",
            _back_kb(
                "menu:categories"
            ),
        )
        return

    subs = await categories.find(
        {"parent_id": cat_id}
    ).sort(
        "name",
        1,
    ).to_list(1000)

    prods = await products.find(
        {"category_id": cat_id}
    ).sort(
        "name",
        1,
    ).to_list(1000)

    rows = []

    text = (
        f"📂 <b>{cat['name']}</b>\n"
    )

    for s in subs:
        rows.append(
            [
                InlineKeyboardButton(
                    f"📁 {s['name']}",
                    callback_data=f"cat:{s['id']}",
                )
            ]
        )

    for p in prods:
        label = (
            f"{p['name']} — "
            f"£{p['price']:.2f}"
        )

        if p.get("stock", 0) <= 0:
            label += " (out)"

        rows.append(
            [
                InlineKeyboardButton(
                    label,
                    callback_data=f"prod:{p['id']}",
                )
            ]
        )

    if not subs and not prods:
        text += "\nNothing here yet."
    else:
        text += "\nSelect an item:"

    parent = cat.get(
        "parent_id"
    )

    back_cb = (
        f"cat:{parent}"
        if parent
        else "menu:categories"
    )

    rows.append(
        [
            InlineKeyboardButton(
                "⬅ Back",
                callback_data=back_cb,
            )
        ]
    )

    await render(
        update,
        context,
        text,
        InlineKeyboardMarkup(rows),
    )


# ===========================================================================
# PRODUCTS
# ===========================================================================

def get_tiers(p):
    tiers = p.get("tiers")

    if tiers:
        return sorted(
            tiers,
            key=lambda t: float(
                t["min"]
            ),
        )

    return [
        {
            "min": 1,
            "price": float(
                p.get(
                    "price",
                    0,
                )
            ),
        }
    ]


def unit_label(p):
    return p.get(
        "unit",
        "pcs",
    )


def price_for_qty(
    p,
    qty,
):
    price = float(
        get_tiers(p)[0]["price"]
    )

    for t in get_tiers(p):
        if qty >= float(t["min"]):
            price = float(
                t["price"]
            )

    return price


def tier_lines(p):
    u = unit_label(p)

    return "\n".join(
        f"• from {float(t['min']):g} "
        f"{u} @ £{float(t['price']):.2f}"
        for t in get_tiers(p)
    )


def _qty_to_int(tok):
    tok = tok.replace(
        ",",
        "",
    )

    if re.fullmatch(
        r"\d+\.\d{3}",
        tok,
    ):
        tok = tok.replace(
            ".",
            "",
        )

    return int(
        round(
            float(tok)
        )
    )


def _parse_tiers(text):
    rows = {}

    for line in (
        text or ""
    ).splitlines():

        nums = re.findall(
            r"\d+(?:[.,]\d+)?",
            line,
        )

        if not nums:
            continue

        try:
            qty = _qty_to_int(
                nums[0]
            )
        except ValueError:
            continue

        m = re.search(
            r"£\s*(\d+(?:[.,]\d+)?)",
            line,
        )

        if m:
            price = float(
                m.group(1).replace(
                    ",",
                    ".",
                )
            )

        elif len(nums) >= 2:
            price = float(
                nums[-1].replace(
                    ",",
                    ".",
                )
            )

        else:
            continue

        if qty > 0:
            rows[qty] = price

    return [
        {
            "min": m,
            "price": rows[m],
        }
        for m in sorted(rows)
    ]


def build_product_view(
    context,
    p,
):
    u = unit_label(p)

    stock = int(
        p.get(
            "stock",
            0,
        )
    )

    floor = int(
        float(
            get_tiers(p)[0]["min"]
        )
    )

    sel = context.user_data.setdefault(
        "sel",
        {},
    )

    qty = int(
        sel.get(
            p["id"],
            floor,
        )
        or floor
    )

    qty = max(
        1,
        qty,
    )

    if stock > 0:
        qty = min(
            qty,
            stock,
        )

    sel[p["id"]] = qty

    unit_price = price_for_qty(
        p,
        qty,
    )

    line_total = (
        unit_price * qty
    )

    stock_line = (
        f"📦 In stock: {stock} {u}"
        if stock > 0
        else "❌ <b>Out of stock</b>"
    )

    caption = (
        f"<b>{p['name']}</b>\n\n"
        f"{p.get('description', '')}\n\n"
        f"💷 <b>Bulk pricing ({u}):</b>\n"
        f"{tier_lines(p)}\n\n"
        f"🧮 Selected: <b>{qty} {u}</b> "
        f"@ £{unit_price:.2f} = "
        f"<b>£{line_total:.2f}</b>\n"
        f"{stock_line}"
    )

    rows = []

    if stock > 0:
        rows.append(
            [
                InlineKeyboardButton(
                    "➖5",
                    callback_data=f"qsel:{p['id']}:-5",
                ),
                InlineKeyboardButton(
                    "➖1",
                    callback_data=f"qsel:{p['id']}:-1",
                ),
                InlineKeyboardButton(
                    f"{qty} {u}",
                    callback_data="noop",
                ),
                InlineKeyboardButton(
                    "➕1",
                    callback_data=f"qsel:{p['id']}:1",
                ),
                InlineKeyboardButton(
                    "➕5",
                    callback_data=f"qsel:{p['id']}:5",
                ),
            ]
        )

        rows.append(
            [
                InlineKeyboardButton(
                    "⌨️ Type quantity",
                    callback_data=f"qtype:{p['id']}",
                )
            ]
        )

        rows.append(
            [
                InlineKeyboardButton(
                    f"🛒 Add {qty} {u} to Cart",
                    callback_data=f"cart:add:{p['id']}",
                )
            ]
        )

    rows.append(
        [
            InlineKeyboardButton(
                "🛒 View Cart",
                callback_data="cart:view",
            ),
            InlineKeyboardButton(
                "⬅ Back",
                callback_data=f"cat:{p['category_id']}",
            ),
        ]
    )

    return (
        caption,
        InlineKeyboardMarkup(rows),
    )


async def show_product(
    update,
    context,
    prod_id,
):
    p = await products.find_one(
        {"id": prod_id}
    )

    if not p:
        await render(
            update,
            context,
            "Product not found.",
            _back_kb(
                "menu:categories"
            ),
        )
        return

    caption, kb = build_product_view(
        context,
        p,
    )

    await render(
        update,
        context,
        caption,
        kb,
        photo=p.get(
            "photo_file_id"
        ),
    )


async def qsel_change(
    update,
    context,
    prod_id,
    delta,
):
    p = await products.find_one(
        {"id": prod_id}
    )

    if not p:
        return

    stock = int(
        p.get(
            "stock",
            0,
        )
    )

    floor = int(
        float(
            get_tiers(p)[0]["min"]
        )
    )

    sel = context.user_data.setdefault(
        "sel",
        {},
    )

    new = max(
        1,
        int(
            sel.get(
                prod_id,
                floor,
            )
            or floor
        )
        + delta,
    )

    if stock > 0:
        new = min(
            new,
            stock,
        )

    sel[prod_id] = new

    caption, kb = build_product_view(
        context,
        p,
    )

    try:
        await update.callback_query.edit_message_caption(
            caption=caption,
            reply_markup=kb,
        )
    except Exception:
        await render(
            update,
            context,
            caption,
            kb,
            photo=p.get(
                "photo_file_id"
            ),
        )


async def start_qty_input(
    update,
    context,
    prod_id,
):
    p = await products.find_one(
        {"id": prod_id}
    )

    if not p:
        await render(
            update,
            context,
            "Product not found.",
            _back_kb(
                "menu:categories"
            ),
        )
        return

    context.user_data["flow"] = {
        "action": "qty_input",
        "data": {
            "product_id": prod_id
        },
    }

    u = unit_label(p)

    await render(
        update,
        context,
        f"⌨️ <b>Type quantity</b> for "
        f"<b>{p['name']}</b>\n\n"
        f"Send the number of {u} you want "
        f"(e.g. <b>40</b>).\n"
        "/cancel to abort.",
        InlineKeyboardMarkup(
            [[
                InlineKeyboardButton(
                    "⬅ Back",
                    callback_data=f"prod:{prod_id}",
                )
            ]]
        ),
    )


async def handle_qty_input(
    update,
    context,
    flow,
):
    prod_id = flow["data"][
        "product_id"
    ]

    nums = re.findall(
        r"\d+(?:[.,]\d+)?",
        update.message.text or "",
    )

    if not nums:
        await update.message.reply_text(
            "Please send a whole number, e.g. 40."
        )
        return

    qty = max(
        1,
        _qty_to_int(nums[0]),
    )

    context.user_data.pop(
        "flow",
        None,
    )

    p = await products.find_one(
        {"id": prod_id}
    )

    if not p:
        await update.message.reply_text(
            "Product no longer available."
        )
        return

    stock = int(
        p.get(
            "stock",
            0,
        )
    )

    if stock > 0 and qty > stock:
        qty = stock

        await update.message.reply_text(
            f"Only {stock} "
            f"{unit_label(p)} in stock — "
            f"set to {stock}."
        )

    context.user_data.setdefault(
        "sel",
        {},
    )[prod_id] = qty

    await show_product(
        update,
        context,
        prod_id,
    )


# ===========================================================================
# CART
# ===========================================================================

async def get_cart(user_id):
    doc = await carts.find_one(
        {"user_id": user_id}
    )

    return (
        doc["items"]
        if doc and doc.get("items")
        else []
    )


async def save_cart(
    user_id,
    items,
):
    await carts.update_one(
        {"user_id": user_id},
        {
            "$set": {
                "items": items
            }
        },
        upsert=True,
    )


async def cart_add(
    update,
    context,
    prod_id,
):
    user_id = update.effective_user.id

    p = await products.find_one(
        {"id": prod_id}
    )

    if not p:
        return

    floor = int(
        float(
            get_tiers(p)[0]["min"]
        )
    )

    add_qty = int(
        context.user_data.get(
            "sel",
            {},
        ).get(
            prod_id,
            floor,
        )
        or floor
    )

    items = await get_cart(
        user_id
    )

    existing = next(
        (
            i
            for i in items
            if i["product_id"] == prod_id
        ),
        None,
    )

    in_cart = (
        existing["qty"]
        if existing
        else 0
    )

    if (
        in_cart + add_qty
        > p.get("stock", 0)
    ):
        await context.bot.answer_callback_query(
            update.callback_query.id,
            "Not enough stock available.",
            show_alert=True,
        )
        return

    if existing:
        existing["qty"] += add_qty
    else:
        items.append(
            {
                "product_id": prod_id,
                "qty": add_qty,
            }
        )

    await save_cart(
        user_id,
        items,
    )

    await context.bot.answer_callback_query(
        update.callback_query.id,
        f"✅ Added {add_qty} "
        f"{unit_label(p)} × "
        f"{p['name']}",
    )

    await show_cart(
        update,
        context,
    )


async def show_cart(
    update,
    context,
):
    user_id = update.effective_user.id

    items = await get_cart(
        user_id
    )

    if not items:
        await render(
            update,
            context,
            "🛒 <b>Your Cart</b>\n\n"
            "Your cart is empty.",
            _back_kb(
                "menu:main"
            ),
        )
        return

    lines = [
        "🛒 <b>Your Cart</b>\n"
    ]

    total = 0.0
    rows = []

    for i in items:
        p = await products.find_one(
            {
                "id":
                    i["product_id"]
            }
        )

        if not p:
            continue

        unit_price = price_for_qty(
            p,
            i["qty"],
        )

        sub = (
            unit_price
            * i["qty"]
        )

        total += sub

        u = unit_label(p)

        lines.append(
            f"• {p['name']} — "
            f"{i['qty']} {u} "
            f"@ £{unit_price:.2f} "
            f"= £{sub:.2f}"
        )

        rows.append(
            [
                InlineKeyboardButton(
                    "➖",
                    callback_data=f"cart:dec:{p['id']}",
                ),
                InlineKeyboardButton(
                    f"{p['name'][:18]} ({i['qty']})",
                    callback_data="noop",
                ),
                InlineKeyboardButton(
                    "➕",
                    callback_data=f"cart:inc:{p['id']}",
                ),
            ]
        )

    lines.append(
        f"\n💷 <b>Total: £{total:.2f}</b>"
    )

    rows.append(
        [
            InlineKeyboardButton(
                "✅ Checkout",
                callback_data="cart:checkout",
            )
        ]
    )

    rows.append(
        [
            InlineKeyboardButton(
                "🗑 Clear",
                callback_data="cart:clear",
            ),
            InlineKeyboardButton(
                "⬅ Menu",
                callback_data="menu:main",
            ),
        ]
    )

    await render(
        update,
        context,
        "\n".join(lines),
        InlineKeyboardMarkup(rows),
    )


async def cart_change_qty(
    update,
    context,
    prod_id,
    delta,
):
    user_id = update.effective_user.id

    items = await get_cart(
        user_id
    )

    item = next(
        (
            i
            for i in items
            if i["product_id"] == prod_id
        ),
        None,
    )

    if not item:
        await show_cart(
            update,
            context,
        )
        return

    if delta > 0:
        p = await products.find_one(
            {"id": prod_id}
        )

        if (
            item["qty"] + 1
            > p.get("stock", 0)
        ):
            await context.bot.answer_callback_query(
                update.callback_query.id,
                "Not enough stock.",
                show_alert=True,
            )
            return

    item["qty"] += delta

    items = [
        i
        for i in items
        if i["qty"] > 0
    ]

    await save_cart(
        user_id,
        items,
    )

    await show_cart(
        update,
        context,
    )


async def cart_clear(
    update,
    context,
):
    await save_cart(
        update.effective_user.id,
        [],
    )

    await show_cart(
        update,
        context,
    )


# ===========================================================================
# CHECKOUT
# ===========================================================================

async def start_checkout(
    update,
    context,
):
    if not await get_cart(
        update.effective_user.id
    ):
        await show_cart(
            update,
            context,
        )
        return

    context.user_data["flow"] = {
        "action": "checkout",
        "step": "details",
    }

    await render(
        update,
        context,
        "✅ <b>Checkout</b>\n\n"
        "Send your delivery details in one message:\n\n"
        "• Full name\n"
        "• Full address + postcode\n"
        "• Contact (phone / @username)\n\n"
        "Type /cancel to abort.",
        InlineKeyboardMarkup(
            [[
                InlineKeyboardButton(
                    "⬅ Back to Cart",
                    callback_data="cart:view",
                )
            ]]
        ),
    )


async def show_payment_methods(
    update,
    context,
):
    rows = [
        [
            InlineKeyboardButton(
                "₿ Pay with Bitcoin",
                callback_data="pay:BTC",
            ),
            InlineKeyboardButton(
                "Ł Pay with Litecoin",
                callback_data="pay:LTC",
            ),
        ],
        [
            InlineKeyboardButton(
                "⬅ Cancel",
                callback_data="menu:main",
            )
        ],
    ]

    await context.bot.send_message(
        update.effective_chat.id,
        "💷 <b>Payment</b>\n\n"
        "Choose how you'd like to pay:",
        reply_markup=InlineKeyboardMarkup(rows),
    )


async def fetch_price_gbp(
    asset,
):
    async with httpx.AsyncClient(
        timeout=12.0
    ) as c:
        r = await c.get(
            COINGECKO_URL,
            params={
                "ids":
                    "bitcoin,litecoin",
                "vs_currencies":
                    "gbp",
            },
        )

        r.raise_for_status()

        data = r.json()

    return Decimal(
        str(
            data[
                COIN_IDS[asset]
            ]["gbp"]
        )
    )


async def create_crypto_order(
    update,
    context,
    asset,
):
    user = update.effective_user
    user_id = user.id

    items = await get_cart(
        user_id
    )

    if not items:
        await show_cart(
            update,
            context,
        )
        return

    order_items = []
    total = Decimal("0")

    for i in items:
        p = await products.find_one(
            {
                "id":
                    i["product_id"]
            }
        )

        if not p:
            continue

        qty = min(
            i["qty"],
            p.get("stock", 0),
        )

        if qty <= 0:
            continue

        unit_price = price_for_qty(
            p,
            qty,
        )

        order_items.append(
            {
                "product_id":
                    p["id"],
                "name":
                    p["name"],
                "price":
                    unit_price,
                "qty":
                    qty,
            }
        )

        total += (
            Decimal(
                str(unit_price)
            )
            * qty
        )

    if not order_items:
        await render(
            update,
            context,
            "Your cart items are no longer available.",
            _back_kb(),
        )
        return

    try:
        price = await fetch_price_gbp(
            asset
        )
    except Exception:
        logger.exception(
            "price fetch failed"
        )

        await context.bot.send_message(
            update.effective_chat.id,
            "⚠️ Could not fetch the live exchange rate. "
            "Please try again in a moment.",
            reply_markup=InlineKeyboardMarkup(
                [[
                    InlineKeyboardButton(
                        "🔁 Try again",
                        callback_data="cart:checkout",
                    )
                ]]
            ),
        )
        return

    base = (
        total / price
    ).quantize(
        Decimal("0.00000001"),
        rounding=ROUND_UP,
    )

    offset_sat = random.randint(
        1,
        9999,
    )

    expected_sat = int(
        (
            base
            * Decimal("100000000")
        ).to_integral_value()
    ) + offset_sat

    amount = (
        Decimal(expected_sat)
        / Decimal("100000000")
    ).quantize(
        Decimal("0.00000001")
    )

    address = COIN_ADDR[asset]

    # Reserve stock.
    for it in order_items:
        await products.update_one(
            {
                "id":
                    it["product_id"]
            },
            {
                "$inc": {
                    "stock":
                        -it["qty"]
                }
            },
        )

    order_no = gen_id()[
        :8
    ].upper()

    order = {
        "id":
            gen_id(),
        "order_no":
            order_no,
        "user_id":
            user_id,
        "username":
            user.username,
        "name":
            user.full_name,
        "items":
            order_items,
        "total_gbp":
            float(total),
        "asset":
            asset,
        "address":
            address,
        "expected_sat":
            expected_sat,
        "crypto_amount":
            f"{amount:.8f}",
        "price_gbp":
            float(price),
        "details":
            context.user_data.get(
                "checkout_details",
                "",
            ),
        "status":
            "awaiting_payment",
        "created_at":
            now_iso(),
    }

    await orders.insert_one(
        order
    )

    await carts.update_one(
        {
            "user_id":
                user_id
        },
        {
            "$set": {
                "items": []
            }
        },
    )

    context.user_data[
        "last_order"
    ] = order["id"]

    await send_invoice(
        update.effective_chat.id,
        context,
        order,
    )

    summary = "\n".join(
        f"• {it['name']} × {it['qty']}"
        for it in order_items
    )

    note = (
        f"🆕 <b>New Order #{order_no}</b> "
        "(awaiting payment)\n\n"
        f"👤 {user.full_name}"
        + (
            f" (@{user.username})"
            if user.username
            else ""
        )
        + f"\n\n{summary}\n\n"
        f"💷 £{total:.2f} → "
        f"{amount:.8f} {asset}\n\n"
        f"📦 <b>Delivery:</b>\n"
        f"{order['details']}"
    )

    for cid in await admin_chat_ids():
        try:
            await context.bot.send_message(
                cid,
                note,
            )
        except Exception:
            pass


async def send_invoice(
    chat_id,
    context,
    order,
):
    asset = order["asset"]

    text = (
        f"🧾 <b>Order #{order['order_no']}</b>\n\n"
        f"Total: <b>£{order['total_gbp']:.2f}</b>\n"
        f"Pay exactly this {asset} amount:\n\n"
        f"💰 Amount: <code>{order['crypto_amount']}</code> "
        f"{asset}\n"
        f"📥 Address:\n"
        f"<code>{order['address']}</code>\n\n"
        "⚠️ Send the <b>exact</b> amount shown "
        "(it identifies your order).\n"
        "After paying, tap the button below to verify.\n"
        "⏱ Rate is valid for ~30 minutes."
    )

    rows = [
        [
            InlineKeyboardButton(
                "✅ I've Paid — Check Payment",
                callback_data=f"pay:check:{order['id']}",
            )
        ],
        [
            InlineKeyboardButton(
                "⬅ Back to Menu",
                callback_data="menu:main",
            )
        ],
    ]

    await context.bot.send_message(
        chat_id,
        text,
        reply_markup=InlineKeyboardMarkup(rows),
    )


async def query_blockchain(
    asset,
    address,
):
    """
    Return list of:
      (received_sat, time_unix_or_None)
    """

    url = ESPLORA_URL[
        asset
    ].format(
        addr=address
    )

    async with httpx.AsyncClient(
        timeout=15.0
    ) as c:
        r = await c.get(url)

        r.raise_for_status()

        txs = r.json()

    out = []

    for t in txs:
        received = sum(
            v.get(
                "value",
                0,
            )
            for v in t.get(
                "vout",
                []
            )
            if v.get(
                "scriptpubkey_address"
            ) == address
        )

        if received <= 0:
            continue

        status = (
            t.get(
                "status",
                {}
            )
            or {}
        )

        out.append(
            (
                int(received),
                status.get(
                    "block_time"
                ),
            )
        )

    return out


async def verify_payment(
    order,
):
    try:
        txs = await query_blockchain(
            order["asset"],
            order["address"],
        )

    except Exception:
        logger.exception(
            "blockchain query failed"
        )
        return None

    created = datetime.fromisoformat(
        order["created_at"]
    )

    cutoff = (
        created
        - timedelta(minutes=5)
    ).timestamp()

    expected = order[
        "expected_sat"
    ]

    for received, t_unix in txs:

        if abs(
            received - expected
        ) <= 2:

            if (
                t_unix is not None
                and t_unix < cutoff
            ):
                continue

            return True

    return False


async def confirm_order_paid(
    context,
    order,
):
    await orders.update_one(
        {
            "id":
                order["id"]
        },
        {
            "$set": {
                "status":
                    "paid",
                "paid_at":
                    now_iso(),
            }
        },
    )

    summary = "\n".join(
        f"• {it['name']} × {it['qty']}"
        for it in order["items"]
    )

    try:
        await context.bot.send_message(
            order["user_id"],
            f"🎉 <b>Payment confirmed — "
            f"Order #{order['order_no']}</b>\n\n"
            f"{summary}\n\n"
            "Thank you! Your order is now being processed. "
            "Use 🚚 Track Order to follow your delivery.",
        )

    except Exception:
        pass

    for cid in await admin_chat_ids():
        try:
            await context.bot.send_message(
                cid,
                f"💰 <b>PAID — "
                f"Order #{order['order_no']}</b>\n"
                f"{summary}",
            )
        except Exception:
            pass


async def check_payment(
    update,
    context,
    order_id,
):
    order = await orders.find_one(
        {
            "id":
                order_id
        }
    )

    if not order:
        await context.bot.answer_callback_query(
            update.callback_query.id,
            "Order not found.",
        )
        return

    if order["status"] == "paid":
        await context.bot.answer_callback_query(
            update.callback_query.id,
            "Already confirmed ✅",
        )
        return

    await context.bot.answer_callback_query(
        update.callback_query.id,
        "🔎 Checking blockchain…",
    )

    result = await verify_payment(
        order
    )

    if result is True:
        await confirm_order_paid(
            context,
            order,
        )

    elif result is False:
        await context.bot.send_message(
            update.effective_chat.id,
            "⏳ Payment not detected yet. "
            "If you've just paid, wait a minute for the network "
            "to broadcast, then check again.",
            reply_markup=InlineKeyboardMarkup(
                [[
                    InlineKeyboardButton(
                        "🔁 Check again",
                        callback_data=f"pay:check:{order_id}",
                    )
                ]]
            ),
        )

    else:
        await context.bot.send_message(
            update.effective_chat.id,
            "⚠️ Couldn't reach the blockchain service right now. "
            "Please try again shortly.",
            reply_markup=InlineKeyboardMarkup(
                [[
                    InlineKeyboardButton(
                        "🔁 Check again",
                        callback_data=f"pay:check:{order_id}",
                    )
                ]]
            ),
        )


async def poll_pending_orders(
    context: ContextTypes.DEFAULT_TYPE,
):
    cutoff = (
        datetime.now(
            timezone.utc
        )
        - timedelta(hours=3)
    ).isoformat()

    pending = await orders.find(
        {
            "status":
                "awaiting_payment",
            "created_at":
                {
                    "$gte":
                        cutoff
                },
        }
    ).sort(
        "created_at",
        1,
    ).to_list(8)

    for order in pending:
        result = await verify_payment(
            order
        )

        if result is True:
            await confirm_order_paid(
                context,
                order,
            )


# ===========================================================================
# REVIEWS / FAQ
# ===========================================================================

async def show_reviews(
    update,
    context,
):
    docs = await reviews.find().sort(
        "created_at",
        -1,
    ).to_list(50)

    avg, count = await rating_summary()

    lines = [
        f"⭐️ <b>Customer Reviews</b>\n\n"
        f"Average: ★{avg} "
        f"({count} reviews)\n"
    ]

    if not docs:
        lines.append(
            "\nNo reviews yet."
        )

    else:
        for d in docs[:25]:
            stars = (
                "★" * d["stars"]
                + "☆" * (
                    5 - d["stars"]
                )
            )

            lines.append(
                f"\n{stars}\n"
                f"{d.get('text', '')}"
            )

    await render(
        update,
        context,
        "\n".join(lines),
        _back_kb(
            "menu:main"
        ),
    )


async def show_faq(
    update,
    context,
):
    await render(
        update,
        context,
        await get_setting(
            "faq",
            DEFAULT_FAQ,
        ),
        _back_kb(
            "menu:main"
        ),
    )


# ===========================================================================
# ORDER TRACKING
# ===========================================================================

def norm_pc(s):
    return (
        s or ""
    ).replace(
        " ",
        "",
    ).upper()


def norm_name(s):
    return (
        s or ""
    ).strip().lower()


async def track_start(
    update,
    context,
):
    context.user_data["flow"] = {
        "action":
            "track",
        "step":
            "name",
        "data":
            {},
    }

    await render(
        update,
        context,
        "🚚 <b>Track Order</b>\n\n"
        "Enter the <b>full name</b> on the order.\n"
        "/cancel to abort.",
        _back_kb(
            "menu:main"
        ),
    )


async def track_search(
    update,
    context,
    name,
    postcode,
):
    docs = await tracking.find(
        {
            "name_norm":
                norm_name(name),
            "postcode_norm":
                norm_pc(postcode),
        }
    ).to_list(20)

    if not docs:
        text = (
            "🚚 <b>Track Order</b>\n\n"
            "❌ No tracking found for that "
            "name + postcode.\n\n"
            "Double-check the spelling, or use "
            "💬 Support Chat for help."
        )

    else:
        lines = [
            "🚚 <b>Tracking Found</b>\n"
        ]

        for d in docs:
            carrier = (
                f" ({d['carrier']})"
                if d.get("carrier")
                else ""
            )

            lines.append(
                f"\n📦 <code>{d['tracking']}</code>"
                f"{carrier}"
            )

        text = "\n".join(
            lines
        )

    await context.bot.send_message(
        update.effective_chat.id,
        text,
        reply_markup=_back_kb(
            "menu:main"
        ),
    )


# ===========================================================================
# SUPPORT
# ===========================================================================

def support_controls():
    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(
                    "❌ Close Chat",
                    callback_data="sup:close",
                ),
                InlineKeyboardButton(
                    "📥 Download Chat",
                    callback_data="sup:download",
                ),
            ]
        ]
    )


async def support_open(
    update,
    context,
):
    user = update.effective_user

    sess = await support.find_one(
        {
            "user_id":
                user.id,
            "status":
                "open",
        }
    )

    if not sess:
        sess = {
            "id":
                gen_id(),
            "user_id":
                user.id,
            "username":
                user.username,
            "name":
                user.full_name,
            "status":
                "open",
            "messages":
                [],
            "created_at":
                now_iso(),
        }

        await support.insert_one(
            sess
        )

    context.user_data["support"] = {
        "role":
            "user",
        "session":
            sess["id"],
    }

    await render(
        update,
        context,
        "💬 <b>Support Chat</b>\n\n"
        "You're connected to our team. Type your message below "
        "and we'll reply here. You can attach a photo too.\n\n"
        "Use the buttons to close or download this chat.",
        support_controls(),
    )


async def support_append(
    sid,
    frm,
    text,
):
    await support.update_one(
        {
            "id":
                sid
        },
        {
            "$push": {
                "messages": {
                    "from":
                        frm,
                    "text":
                        text,
                    "ts":
                        now_iso(),
                }
            }
        },
    )


async def support_relay_from_user(
    update,
    context,
    sess,
):
    text = (
        update.message.text
        or (
            "[photo]"
            if update.message.photo
            else ""
        )
    )

    await support_append(
        sess["id"],
        "customer",
        text,
    )

    user = update.effective_user

    header = (
        f"💬 <b>Support message</b>\n"
        f"From: {user.full_name}"
        + (
            f" (@{user.username})"
            if user.username
            else ""
        )
        + f"\nSession: <code>{sess['id']}</code>\n\n"
        f"{text}"
    )

    kb = InlineKeyboardMarkup(
        [[
            InlineKeyboardButton(
                "💬 Reply",
                callback_data=f"sup:reply:{sess['id']}",
            )
        ]]
    )

    for cid in await admin_chat_ids():
        try:
            if update.message.photo:
                await context.bot.send_photo(
                    cid,
                    photo=update.message.photo[-1].file_id,
                    caption=header,
                    reply_markup=kb,
                )

            else:
                await context.bot.send_message(
                    cid,
                    header,
                    reply_markup=kb,
                )

        except Exception:
            pass

    await update.message.reply_text(
        "✓ Sent to support.",
        reply_markup=support_controls(),
    )


async def support_relay_from_admin(
    update,
    context,
    sess,
):
    text = (
        update.message.text
        or (
            "[photo]"
            if update.message.photo
            else ""
        )
    )

    await support_append(
        sess["id"],
        "support",
        text,
    )

    body = (
        "💬 <b>Support reply</b>\n\n"
        f"{text}"
    )

    try:
        if update.message.photo:
            await context.bot.send_photo(
                sess["user_id"],
                photo=update.message.photo[-1].file_id,
                caption=body,
                reply_markup=support_controls(),
            )

        else:
            await context.bot.send_message(
                sess["user_id"],
                body,
                reply_markup=support_controls(),
            )

        await update.message.reply_text(
            "✓ Delivered to customer.",
            reply_markup=support_controls(),
        )

    except Exception:
        await update.message.reply_text(
            "⚠️ Could not deliver "
            "(customer may have blocked the bot)."
        )


async def support_reply(
    update,
    context,
    sid,
):
    sess = await support.find_one(
        {"id": sid}
    )

    if not sess or sess["status"] != "open":
        await context.bot.answer_callback_query(
            update.callback_query.id,
            "Chat is closed.",
        )
        return

    context.user_data["support"] = {
        "role":
            "admin",
        "session":
            sid,
    }

    await context.bot.send_message(
        update.effective_chat.id,
        f"💬 Replying to "
        f"<b>{sess.get('name', 'customer')}</b>. "
        "Type your message; it will be sent to the customer. "
        "Use the buttons to close or download.",
        reply_markup=support_controls(),
    )


async def support_close(
    update,
    context,
):
    sup = context.user_data.get(
        "support"
    )

    if not sup:
        await context.bot.answer_callback_query(
            update.callback_query.id,
            "No active chat.",
        )
        return

    sess = await support.find_one(
        {
            "id":
                sup["session"]
        }
    )

    await support.update_one(
        {
            "id":
                sup["session"]
        },
        {
            "$set": {
                "status":
                    "closed",
                "closed_at":
                    now_iso(),
            }
        },
    )

    context.user_data.pop(
        "support",
        None,
    )

    await context.bot.answer_callback_query(
        update.callback_query.id,
        "Chat closed.",
    )

    await context.bot.send_message(
        update.effective_chat.id,
        "✅ Support chat closed.",
    )

    if sess:
        other = (
            sess["user_id"]
            if sup["role"] == "admin"
            else None
        )

        if (
            sup["role"] == "admin"
            and other
        ):
            try:
                await context.bot.send_message(
                    other,
                    "💬 Support has closed this chat. Thanks!",
                )
            except Exception:
                pass


async def support_download(
    update,
    context,
):
    sup = context.user_data.get(
        "support"
    )

    if not sup:
        await context.bot.answer_callback_query(
            update.callback_query.id,
            "No active chat.",
        )
        return

    sess = await support.find_one(
        {
            "id":
                sup["session"]
        }
    )

    if not sess:
        await context.bot.answer_callback_query(
            update.callback_query.id,
            "Chat not found.",
        )
        return

    await context.bot.answer_callback_query(
        update.callback_query.id
    )

    lines = [
        "Ball Supplies — Support Chat Transcript",
        f"Session: {sess['id']}",
        (
            f"Customer: "
            f"{sess.get('name')} "
            f"(@{sess.get('username')})"
        ),
        f"Opened: {sess.get('created_at')}",
        "=" * 40,
    ]

    for m in sess.get(
        "messages",
        [],
    ):
        who = (
            "Customer"
            if m["from"] == "customer"
            else "Support"
        )

        lines.append(
            f"[{m['ts']}] "
            f"{who}: {m['text']}"
        )

    buf = BytesIO(
        "\n".join(lines).encode(
            "utf-8"
        )
    )

    buf.name = (
        f"support_{sess['id']}.txt"
    )

    await context.bot.send_document(
        update.effective_chat.id,
        document=InputFile(buf),
        caption="📥 Chat transcript",
    )


# ===========================================================================
# ADMIN PANEL
# ===========================================================================

async def admin_panel(
    update,
    context,
):
    if not is_admin(update):
        await context.bot.answer_callback_query(
            update.callback_query.id,
            "Admins only.",
            show_alert=True,
        )
        return

    await track_admin(update)

    rows = [
        [
            InlineKeyboardButton(
                "➕ Add Category",
                callback_data="admin:addcat",
            ),
            InlineKeyboardButton(
                "➖ Remove Category",
                callback_data="admin:delcat",
            ),
        ],
        [
            InlineKeyboardButton(
                "➕ Add Product",
                callback_data="admin:addprod",
            ),
            InlineKeyboardButton(
                "➖ Remove Product",
                callback_data="admin:delprod",
            ),
        ],
        [
            InlineKeyboardButton(
                "⭐️ Add Review",
                callback_data="admin:addrev",
            ),
            InlineKeyboardButton(
                "🗑 Remove Review",
                callback_data="admin:delrev",
            ),
        ],
        [
            InlineKeyboardButton(
                "🚚 Add Tracking",
                callback_data="admin:addtrack",
            ),
            InlineKeyboardButton(
                "🗑 Remove Tracking",
                callback_data="admin:deltrack",
            ),
        ],
        [
            InlineKeyboardButton(
                "📝 Edit FAQ",
                callback_data="admin:editfaq",
            ),
            InlineKeyboardButton(
                "📦 Orders",
                callback_data="admin:orders",
            ),
        ],
        [
            InlineKeyboardButton(
                "⬅ Back to Menu",
                callback_data="menu:main",
            )
        ],
    ]

    await render(
        update,
        context,
        "👑 <b>Admin Panel</b>\n\n"
        "Manage your shop:",
        InlineKeyboardMarkup(rows),
    )


async def admin_add_category(
    update,
    context,
):
    cats = await categories.find().sort(
        "name",
        1,
    ).to_list(1000)

    rows = [
        [
            InlineKeyboardButton(
                "⬆ Top Level (no parent)",
                callback_data="admin:addcat:root",
            )
        ]
    ]

    for c in cats:
        rows.append(
            [
                InlineKeyboardButton(
                    f"📁 inside: {c['name']}",
                    callback_data=f"admin:addcat:{c['id']}",
                )
            ]
        )

    rows.append(
        [
            InlineKeyboardButton(
                "⬅ Admin Panel",
                callback_data="admin:panel",
            )
        ]
    )

    await render(
        update,
        context,
        "➕ <b>Add Category</b>\n\n"
        "Where should it go? Pick a parent "
        "(for a sub-category) or Top Level:",
        InlineKeyboardMarkup(rows),
    )


async def admin_add_category_name(
    update,
    context,
    parent,
):
    context.user_data["flow"] = {
        "action":
            "add_category",
        "data": {
            "parent_id":
                None
                if parent == "root"
                else parent
        },
    }

    where = (
        "top level"
        if parent == "root"
        else "sub-category"
    )

    await render(
        update,
        context,
        f"➕ <b>Add {where}</b>\n\n"
        "Send the category name.\n"
        "/cancel to abort.",
    )


async def admin_del_category_list(
    update,
    context,
):
    cats = await categories.find().sort(
        "name",
        1,
    ).to_list(1000)

    rows = []

    if not cats:
        text = (
            "No categories to remove."
        )

    else:
        text = (
            "➖ <b>Remove Category</b>\n\n"
            "Tap to delete "
            "(also removes its sub-categories "
            "& products):"
        )

        for c in cats:
            tag = (
                "📁"
                if c.get("parent_id")
                else "📂"
            )

            rows.append(
                [
                    InlineKeyboardButton(
                        f"🗑 {tag} {c['name']}",
                        callback_data=f"admin:delcat:{c['id']}",
                    )
                ]
            )

    rows.append(
        [
            InlineKeyboardButton(
                "⬅ Admin Panel",
                callback_data="admin:panel",
            )
        ]
    )

    await render(
        update,
        context,
        text,
        InlineKeyboardMarkup(rows),
    )


async def _delete_category_recursive(
    cat_id,
):
    await products.delete_many(
        {
            "category_id":
                cat_id
        }
    )

    subs = await categories.find(
        {
            "parent_id":
                cat_id
        }
    ).to_list(1000)

    for s in subs:
        await _delete_category_recursive(
            s["id"]
        )

    await categories.delete_one(
        {
            "id":
                cat_id
        }
    )


async def admin_del_category(
    update,
    context,
    cat_id,
):
    cat = await categories.find_one(
        {
            "id":
                cat_id
        }
    )

    await _delete_category_recursive(
        cat_id
    )

    await context.bot.answer_callback_query(
        update.callback_query.id,
        (
            f"Deleted '{cat['name']}'"
            if cat
            else "Deleted"
        ),
    )

    await admin_del_category_list(
        update,
        context,
    )


async def admin_add_product(
    update,
    context,
):
    cats = await categories.find().sort(
        "name",
        1,
    ).to_list(1000)

    if not cats:
        await render(
            update,
            context,
            "Please add a category first.",
            admin_back_kb(),
        )
        return

    rows = []

    for c in cats:
        tag = (
            "📁"
            if c.get("parent_id")
            else "📂"
        )

        rows.append(
            [
                InlineKeyboardButton(
                    f"{tag} {c['name']}",
                    callback_data=f"admin:addprod:{c['id']}",
                )
            ]
        )

    rows.append(
        [
            InlineKeyboardButton(
                "⬅ Admin Panel",
                callback_data="admin:panel",
            )
        ]
    )

    await render(
        update,
        context,
        "➕ <b>Add Product</b>\n\n"
        "Select the category:",
        InlineKeyboardMarkup(rows),
    )


async def admin_add_product_start(
    update,
    context,
    cat_id,
):
    context.user_data["flow"] = {
        "action":
            "add_product",
        "step":
            "name",
        "data": {
            "category_id":
                cat_id
        },
    }

    await render(
        update,
        context,
        "➕ <b>Add Product</b>\n\n"
        "Step 1/6 — Send the product "
        "<b>name</b>.\n"
        "/cancel to abort.",
    )


async def admin_del_product_list(
    update,
    context,
):
    prods = await products.find().sort(
        "name",
        1,
    ).to_list(1000)

    rows = []

    if not prods:
        text = (
            "No products to remove."
        )

    else:
        text = (
            "➖ <b>Remove Product</b>\n\n"
            "Tap a product to delete it:"
        )

        for p in prods:
            rows.append(
                [
                    InlineKeyboardButton(
                        f"🗑 {p['name']} "
                        f"(£{p['price']:.2f})",
                        callback_data=f"admin:delprod:{p['id']}",
                    )
                ]
            )

    rows.append(
        [
            InlineKeyboardButton(
                "⬅ Admin Panel",
                callback_data="admin:panel",
            )
        ]
    )

    await render(
        update,
        context,
        text,
        InlineKeyboardMarkup(rows),
    )


async def admin_del_product(
    update,
    context,
    prod_id,
):
    p = await products.find_one(
        {
            "id":
                prod_id
        }
    )

    await products.delete_one(
        {
            "id":
                prod_id
        }
    )

    await context.bot.answer_callback_query(
        update.callback_query.id,
        (
            f"Deleted '{p['name']}'"
            if p
            else "Deleted"
        ),
    )

    await admin_del_product_list(
        update,
        context,
    )


async def admin_add_review(
    update,
    context,
):
    rows = [
        [
            InlineKeyboardButton(
                "★" * n,
                callback_data=f"admin:revstar:{n}",
            )
            for n in (1, 2, 3)
        ],
        [
            InlineKeyboardButton(
                "★" * n,
                callback_data=f"admin:revstar:{n}",
            )
            for n in (4, 5)
        ],
        [
            InlineKeyboardButton(
                "⬅ Admin Panel",
                callback_data="admin:panel",
            )
        ],
    ]

    await render(
        update,
        context,
        "⭐️ <b>Add Review</b>\n\n"
        "Step 1/2 — Choose a star rating:",
        InlineKeyboardMarkup(rows),
    )


async def admin_review_stars(
    update,
    context,
    stars,
):
    context.user_data["flow"] = {
        "action":
            "add_review",
        "data": {
            "stars":
                stars
        },
    }

    await render(
        update,
        context,
        f"⭐️ <b>Add Review</b>\n\n"
        f"Rating: "
        f"{'★' * stars}"
        f"{'☆' * (5 - stars)}\n\n"
        "Step 2/2 — Type the review text.\n"
        "/cancel to abort.",
    )


async def admin_del_review_list(
    update,
    context,
):
    docs = await reviews.find().sort(
        "created_at",
        -1,
    ).to_list(100)

    rows = []

    if not docs:
        text = (
            "No reviews to remove."
        )

    else:
        text = (
            "🗑 <b>Remove Review</b>\n\n"
            "Tap a review to delete it:"
        )

        for d in docs:
            preview = (
                d.get(
                    "text",
                    "",
                )
                or ""
            )[:25]

            rows.append(
                [
                    InlineKeyboardButton(
                        f"{'★' * d['stars']} "
                        f"— {preview}",
                        callback_data=f"admin:delrev:{d['id']}",
                    )
                ]
            )

    rows.append(
        [
            InlineKeyboardButton(
                "⬅ Admin Panel",
                callback_data="admin:panel",
            )
        ]
    )

    await render(
        update,
        context,
        text,
        InlineKeyboardMarkup(rows),
    )


async def admin_del_review(
    update,
    context,
    rev_id,
):
    await reviews.delete_one(
        {
            "id":
                rev_id
        }
    )

    await context.bot.answer_callback_query(
        update.callback_query.id,
        "Review deleted",
    )

    await admin_del_review_list(
        update,
        context,
    )


async def admin_add_tracking(
    update,
    context,
):
    context.user_data["flow"] = {
        "action":
            "add_tracking",
        "step":
            "name",
        "data":
            {},
    }

    await render(
        update,
        context,
        "🚚 <b>Add Tracking</b>\n\n"
        "Step 1/4 — Send the customer's "
        "<b>full name</b> "
        "(as the customer will type it).\n"
        "/cancel to abort.",
    )


async def admin_del_tracking_list(
    update,
    context,
):
    docs = await tracking.find().sort(
        "created_at",
        -1,
    ).to_list(100)

    rows = []

    if not docs:
        text = (
            "No tracking entries."
        )

    else:
        text = (
            "🗑 <b>Remove Tracking</b>\n\n"
            "Tap an entry to delete it:"
        )

        for d in docs:
            rows.append(
                [
                    InlineKeyboardButton(
                        f"🗑 {d['name']} • "
                        f"{d['postcode']} • "
                        f"{d['tracking'][:12]}",
                        callback_data=f"admin:deltrack:{d['id']}",
                    )
                ]
            )

    rows.append(
        [
            InlineKeyboardButton(
                "⬅ Admin Panel",
                callback_data="admin:panel",
            )
        ]
    )

    await render(
        update,
        context,
        text,
        InlineKeyboardMarkup(rows),
    )


async def admin_del_tracking(
    update,
    context,
    tid,
):
    await tracking.delete_one(
        {
            "id":
                tid
        }
    )

    await context.bot.answer_callback_query(
        update.callback_query.id,
        "Tracking removed",
    )

    await admin_del_tracking_list(
        update,
        context,
    )


async def admin_edit_faq(
    update,
    context,
):
    context.user_data["flow"] = {
        "action":
            "edit_faq"
    }

    current = await get_setting(
        "faq",
        DEFAULT_FAQ,
    )

    await render(
        update,
        context,
        "📝 <b>Edit FAQ</b>\n\n"
        "Send the new FAQ text.\n"
        "/cancel to abort.\n\n"
        "<b>Current:</b>\n"
        f"{current}",
    )


async def admin_orders(
    update,
    context,
):
    docs = await orders.find().sort(
        "created_at",
        -1,
    ).to_list(20)

    if not docs:
        await render(
            update,
            context,
            "📦 <b>Orders</b>\n\n"
            "No orders yet.",
            admin_back_kb(),
        )
        return

    lines = [
        "📦 <b>Recent Orders</b>\n"
    ]

    for o in docs:
        uname = (
            f"@{o['username']}"
            if o.get("username")
            else o.get(
                "name",
                "",
            )
        )

        items = ", ".join(
            f"{it['name']}×{it['qty']}"
            for it in o["items"]
        )

        emoji = (
            "💰"
            if o["status"] == "paid"
            else "⏳"
        )

        lines.append(
            f"\n{emoji} "
            f"#{o['order_no']} — "
            f"{uname}\n"
            f"{items}\n"
            f"£{o['total_gbp']:.2f} • "
            f"{o.get('crypto_amount', '')} "
            f"{o.get('asset', '')} • "
            f"{o['status']}"
        )

    await render(
        update,
        context,
        "\n".join(lines),
        admin_back_kb(),
    )


async def _admin_done(
    update,
    context,
    msg,
):
    context.user_data.pop(
        "flow",
        None,
    )

    await update.message.reply_text(
        msg
    )

    await context.bot.send_message(
        update.effective_chat.id,
        "👑 <b>Admin Panel</b>",
        reply_markup=admin_back_kb(),
    )


# ===========================================================================
# CALLBACK ROUTER
# ===========================================================================

async def on_callback(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    query = update.callback_query
    data = query.data or ""

    await track_admin(update)

    if data == "noop":
        await query.answer()
        return

    instant_answer = (
        data.split(":")[0]
        in (
            "cart",
            "pay",
            "sup",
        )
        and (
            data.startswith(
                "cart:add"
            )
            or data.startswith(
                "cart:inc"
            )
            or data.startswith(
                "cart:dec"
            )
            or data.startswith(
                "pay:check"
            )
            or data == "sup:close"
            or data == "sup:download"
            or data.startswith(
                "sup:reply"
            )
        )
    )

    if not instant_answer:
        await query.answer()

    parts = data.split(":")
    head = parts[0]

    try:

        # ------------------------------------------------------------------
        # MENU
        # ------------------------------------------------------------------

        if head == "menu":
            sub = parts[1]

            if sub == "main":
                await show_main_menu(
                    update,
                    context,
                )

            elif sub == "categories":
                await show_categories(
                    update,
                    context,
                )

            elif sub == "reviews":
                await show_reviews(
                    update,
                    context,
                )

            elif sub == "faq":
                await show_faq(
                    update,
                    context,
                )

        # ------------------------------------------------------------------
        # CATEGORY
        # ------------------------------------------------------------------

        elif head == "cat":
            await show_category(
                update,
                context,
                parts[1],
            )

        # ------------------------------------------------------------------
        # PRODUCT
        # ------------------------------------------------------------------

        elif head == "prod":
            await show_product(
                update,
                context,
                parts[1],
            )

        elif head == "qsel":
            await qsel_change(
                update,
                context,
                parts[1],
                int(parts[2]),
            )

        elif head == "qtype":
            await start_qty_input(
                update,
                context,
                parts[1],
            )

        elif head == "punit":
            if not is_admin(update):
                await query.answer(
                    "Admins only.",
                    show_alert=True,
                )
            else:
                await admin_product_unit(
                    update,
                    context,
                    parts[1],
                )

        # ------------------------------------------------------------------
        # CART
        # ------------------------------------------------------------------

        elif head == "cart":
            sub = parts[1]

            if sub == "add":
                await cart_add(
                    update,
                    context,
                    parts[2],
                )

            elif sub == "view":
                await show_cart(
                    update,
                    context,
                )

            elif sub == "inc":
                await query.answer()

                await cart_change_qty(
                    update,
                    context,
                    parts[2],
                    +1,
                )

            elif sub == "dec":
                await query.answer()

                await cart_change_qty(
                    update,
                    context,
                    parts[2],
                    -1,
                )

            elif sub == "clear":
                await cart_clear(
                    update,
                    context,
                )

            elif sub == "checkout":
                await start_checkout(
                    update,
                    context,
                )

        # ------------------------------------------------------------------
        # PAYMENT
        # ------------------------------------------------------------------

        elif head == "pay":
            sub = parts[1]

            if sub in (
                "BTC",
                "LTC",
            ):
                await create_crypto_order(
                    update,
                    context,
                    sub,
                )

            elif sub == "check":
                await check_payment(
                    update,
                    context,
                    parts[2],
                )

        # ------------------------------------------------------------------
        # TRACKING
        # ------------------------------------------------------------------

        elif head == "track":
            await track_start(
                update,
                context,
            )

        # ------------------------------------------------------------------
        # SUPPORT
        # ------------------------------------------------------------------

        elif head == "sup":
            sub = parts[1]

            if sub == "open":
                await support_open(
                    update,
                    context,
                )

            elif sub == "close":
                await support_close(
                    update,
                    context,
                )

            elif sub == "download":
                await support_download(
                    update,
                    context,
                )

            elif sub == "reply":
                if not is_admin(update):
                    await query.answer(
                        "Admins only.",
                        show_alert=True,
                    )
                else:
                    await support_reply(
                        update,
                        context,
                        parts[2],
                    )

        # ------------------------------------------------------------------
        # ADMIN
        # ------------------------------------------------------------------

        elif head == "admin":

            if not is_admin(update):
                await query.answer(
                    "Admins only.",
                    show_alert=True,
                )
                return

            sub = parts[1]

            if sub == "panel":
                await admin_panel(
                    update,
                    context,
                )

            elif sub == "addcat":
                if len(parts) == 3:
                    await admin_add_category_name(
                        update,
                        context,
                        parts[2],
                    )
                else:
                    await admin_add_category(
                        update,
                        context,
                    )

            elif sub == "delcat":
                if len(parts) == 3:
                    await admin_del_category(
                        update,
                        context,
                        parts[2],
                    )
                else:
                    await admin_del_category_list(
                        update,
                        context,
                    )

            elif sub == "addprod":
                if len(parts) == 3:
                    await admin_add_product_start(
                        update,
                        context,
                        parts[2],
                    )
                else:
                    await admin_add_product(
                        update,
                        context,
                    )

            elif sub == "delprod":
                if len(parts) == 3:
                    await admin_del_product(
                        update,
                        context,
                        parts[2],
                    )
                else:
                    await admin_del_product_list(
                        update,
                        context,
                    )

            elif sub == "addrev":
                await admin_add_review(
                    update,
                    context,
                )

            elif sub == "revstar":
                await admin_review_stars(
                    update,
                    context,
                    int(parts[2]),
                )

            elif sub == "delrev":
                if len(parts) == 3:
                    await admin_del_review(
                        update,
                        context,
                        parts[2],
                    )
                else:
                    await admin_del_review_list(
                        update,
                        context,
                    )

            elif sub == "addtrack":
                await admin_add_tracking(
                    update,
                    context,
                )

            elif sub == "deltrack":
                if len(parts) == 3:
                    await admin_del_tracking(
                        update,
                        context,
                        parts[2],
                    )
                else:
                    await admin_del_tracking_list(
                        update,
                        context,
                    )

            elif sub == "editfaq":
                await admin_edit_faq(
                    update,
                    context,
                )

            elif sub == "orders":
                await admin_orders(
                    update,
                    context,
                )

    except Exception:
        logger.exception(
            "callback error for data=%s",
            data,
        )


# ===========================================================================
# MESSAGE HANDLER
# ===========================================================================

async def on_message(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    await track_admin(update)

    flow = context.user_data.get(
        "flow"
    )

    if flow:
        action = flow["action"]

        # --------------------------------------------------------------
        # CHECKOUT
        # --------------------------------------------------------------

        if action == "checkout":
            text = update.message.text

            if not text:
                await update.message.reply_text(
                    "Please send your delivery details as text."
                )
                return

            context.user_data[
                "checkout_details"
            ] = text.strip()

            context.user_data.pop(
                "flow",
                None,
            )

            await show_payment_methods(
                update,
                context,
            )

            return

        # --------------------------------------------------------------
        # TRACK
        # --------------------------------------------------------------

        if action == "track":
            await handle_track_step(
                update,
                context,
                flow,
            )
            return

        # --------------------------------------------------------------
        # QUANTITY
        # --------------------------------------------------------------

        if action == "qty_input":
            await handle_qty_input(
                update,
                context,
                flow,
            )
            return

        # --------------------------------------------------------------
        # ADMIN
        # --------------------------------------------------------------

        if not is_admin(update):
            context.user_data.pop(
                "flow",
                None,
            )
            return

        if action == "add_category":

            name = (
                update.message.text
                or ""
            ).strip()

            if not name:
                await update.message.reply_text(
                    "Please send a valid name."
                )
                return

            await categories.insert_one(
                {
                    "id":
                        gen_id(),
                    "name":
                        name,
                    "parent_id":
                        flow["data"]["parent_id"],
                    "created_at":
                        now_iso(),
                }
            )

            await _admin_done(
                update,
                context,
                f"✅ Category '{name}' added.",
            )

        elif action == "add_product":

            await handle_add_product_step(
                update,
                context,
                flow,
            )

        elif action == "add_review":

            text = (
                update.message.text
                or ""
            ).strip()

            if not text:
                await update.message.reply_text(
                    "Please send the review text."
                )
                return

            await reviews.insert_one(
                {
                    "id":
                        gen_id(),
                    "stars":
                        flow["data"]["stars"],
                    "text":
                        text,
                    "created_at":
                        now_iso(),
                }
            )

            await _admin_done(
                update,
                context,
                "✅ Review added.",
            )

        elif action == "add_tracking":

            await handle_add_tracking_step(
                update,
                context,
                flow,
            )

        elif action == "edit_faq":

            text = (
                update.message.text
                or ""
            ).strip()

            if not text:
                await update.message.reply_text(
                    "Please send the FAQ text."
                )
                return

            await set_setting(
                "faq",
                text,
            )

            await _admin_done(
                update,
                context,
                "✅ FAQ updated.",
            )

        return

    # ------------------------------------------------------------------
    # NO FLOW -> SUPPORT
    # ------------------------------------------------------------------

    sup = context.user_data.get(
        "support"
    )

    if sup:
        sess = await support.find_one(
            {
                "id":
                    sup["session"]
            }
        )

        if (
            not sess
            or sess["status"] != "open"
        ):
            context.user_data.pop(
                "support",
                None,
            )

            await update.message.reply_text(
                "💬 This support chat has been closed."
            )

            return

        if sup["role"] == "admin":
            await support_relay_from_admin(
                update,
                context,
                sess,
            )

        else:
            await support_relay_from_user(
                update,
                context,
                sess,
            )


# ===========================================================================
# TRACKING FLOW
# ===========================================================================

async def handle_track_step(
    update,
    context,
    flow,
):
    data = flow["data"]

    if flow["step"] == "name":

        data["name"] = (
            update.message.text
            or ""
        ).strip()

        flow["step"] = "postcode"

        await update.message.reply_text(
            "Now enter the <b>postcode</b> on the order."
        )

    else:

        postcode = (
            update.message.text
            or ""
        ).strip()

        context.user_data.pop(
            "flow",
            None,
        )

        await track_search(
            update,
            context,
            data["name"],
            postcode,
        )


# ===========================================================================
# ADMIN TRACKING FLOW
# ===========================================================================

async def handle_add_tracking_step(
    update,
    context,
    flow,
):
    data = flow["data"]
    msg = update.message
    step = flow["step"]

    if step == "name":

        data["name"] = (
            msg.text
            or ""
        ).strip()

        flow["step"] = "postcode"

        await msg.reply_text(
            "Step 2/4 — Send the <b>postcode</b>."
        )

    elif step == "postcode":

        data["postcode"] = (
            msg.text
            or ""
        ).strip()

        flow["step"] = "tracking"

        await msg.reply_text(
            "Step 3/4 — Send the "
            "<b>tracking number</b>."
        )

    elif step == "tracking":

        data["tracking"] = (
            msg.text
            or ""
        ).strip()

        flow["step"] = "carrier"

        await msg.reply_text(
            "Step 4/4 — Send the <b>carrier</b> "
            "name (or type '-' to skip)."
        )

    elif step == "carrier":

        carrier = (
            msg.text
            or ""
        ).strip()

        if carrier == "-":
            carrier = ""

        await tracking.insert_one(
            {
                "id":
                    gen_id(),
                "name":
                    data["name"],
                "name_norm":
                    norm_name(
                        data["name"]
                    ),
                "postcode":
                    data["postcode"],
                "postcode_norm":
                    norm_pc(
                        data["postcode"]
                    ),
                "tracking":
                    data["tracking"],
                "carrier":
                    carrier,
                "created_at":
                    now_iso(),
            }
        )

        await _admin_done(
            update,
            context,
            f"✅ Tracking added for "
            f"{data['name']} "
            f"({data['postcode']}).",
        )


# ===========================================================================
# PRODUCT UNIT
# ===========================================================================

async def admin_product_unit(
    update,
    context,
    unit,
):
    flow = context.user_data.get(
        "flow"
    )

    if (
        not flow
        or flow.get("action")
        != "add_product"
        or flow.get("step")
        != "unit"
    ):
        await context.bot.answer_callback_query(
            update.callback_query.id,
            "Start adding a product first.",
        )
        return

    flow["data"]["unit"] = unit
    flow["step"] = "tiers"

    await render(
        update,
        context,
        f"Step 3/6 — Unit: <b>{unit}</b>\n\n"
        "Now send your <b>bulk price tiers</b>, "
        "one per line as "
        "<code>&lt;qty&gt; &lt;price&gt;</code>:\n\n"
        "Example:\n"
        "<code>"
        "1 5.00\n"
        "3 4.50\n"
        "5 3.75\n"
        "10 3.30\n"
        "25 2.70\n"
        "50 2.20"
        "</code>\n\n"
        "You can also paste lines like "
        "<code>from 3 pcs @ £4.50</code>.\n"
        "For thousands, write "
        "<code>10000</code> or "
        "<code>10,000</code> — not "
        "<code>10.000</code>.\n"
        "/cancel to abort.",
    )


# ===========================================================================
# ADD PRODUCT FLOW
# ===========================================================================

async def handle_add_product_step(
    update,
    context,
    flow,
):
    step = flow["step"]
    data = flow["data"]
    msg = update.message

    if step == "name":

        name = (
            msg.text
            or ""
        ).strip()

        if not name:
            await msg.reply_text(
                "Please send a valid name."
            )
            return

        data["name"] = name
        flow["step"] = "unit"

        await msg.reply_text(
            "Step 2/6 — Choose the "
            "<b>unit</b> for this product:",
            reply_markup=InlineKeyboardMarkup(
                [[
                    InlineKeyboardButton(
                        "📦 pcs",
                        callback_data="punit:pcs",
                    ),
                    InlineKeyboardButton(
                        "⚖️ g",
                        callback_data="punit:g",
                    ),
                ]]
            ),
        )

    elif step == "tiers":

        tiers = _parse_tiers(
            msg.text
            or ""
        )

        if not tiers:
            await msg.reply_text(
                "Couldn't read any tiers. "
                "Send one per line as: "
                "<qty> <price>\n\n"
                "Example:\n"
                "1 5.00\n"
                "3 4.50\n"
                "5 3.75"
            )
            return

        data["tiers"] = tiers
        data["price"] = tiers[0]["price"]

        flow["step"] = "description"

        summary = "\n".join(
            f"• from {t['min']:g} "
            f"@ £{t['price']:.2f}"
            for t in tiers
        )

        await msg.reply_text(
            f"✅ Tiers set:\n"
            f"{summary}\n\n"
            "Step 4/6 — Send the product "
            "<b>description</b>."
        )

    elif step == "description":

        data["description"] = (
            msg.text
            or ""
        ).strip()

        flow["step"] = "stock"

        await msg.reply_text(
            f"Step 5/6 — Send the "
            f"<b>stock quantity</b> in "
            f"{data.get('unit', 'pcs')} "
            "(whole number)."
        )

    elif step == "stock":

        try:
            stock = int(
                (
                    msg.text
                    or ""
                ).strip()
            )

            if stock < 0:
                raise ValueError

        except ValueError:
            await msg.reply_text(
                "Invalid quantity. "
                "Send a whole number, e.g. 100"
            )
            return

        data["stock"] = stock
        flow["step"] = "photo"

        await msg.reply_text(
            "Step 6/6 — Send a "
            "<b>photo</b> of the product."
        )

    elif step == "photo":

        if not msg.photo:
            await msg.reply_text(
                "Please send a photo (image)."
            )
            return

        await products.insert_one(
            {
                "id":
                    gen_id(),
                "category_id":
                    data["category_id"],
                "name":
                    data["name"],
                "unit":
                    data.get(
                        "unit",
                        "pcs",
                    ),
                "tiers":
                    data["tiers"],
                "price":
                    data["price"],
                "description":
                    data["description"],
                "stock":
                    data["stock"],
                "photo_file_id":
                    msg.photo[-1].file_id,
                "created_at":
                    now_iso(),
            }
        )

        await _admin_done(
            update,
            context,
            f"✅ Product "
            f"'{data['name']}' added.",
        )


# ===========================================================================
# BOT STARTUP
# ===========================================================================

async def post_init(
    app: Application,
):
    await app.bot.set_my_commands(
        [
            (
                "start",
                "Open the shop",
            ),
            (
                "back",
                "Back to main menu",
            ),
            (
                "menu",
                "Back to main menu",
            ),
            (
                "cancel",
                "Cancel current action",
            ),
        ]
    )

    logger.info(
        "✅ SQLite database ready: %s",
        DB_PATH,
    )

    logger.info(
        "Ball Supplies bot ready. "
        "Admins: %s",
        ADMIN_USERNAMES,
    )


async def on_error(
    update,
    context,
):
    logger.error(
        "Handler error while processing update: %s",
        context.error,
        exc_info=context.error,
    )

    try:
        if (
            isinstance(update, Update)
            and update.effective_chat
        ):
            await context.bot.send_message(
                update.effective_chat.id,
                "⚠️ Something went wrong on our side. "
                "Please try again in a moment.",
            )

    except Exception:
        pass


def build_app():
    app = (
        ApplicationBuilder()
        .token(TOKEN)
        .defaults(
            Defaults(
                parse_mode=ParseMode.HTML
            )
        )
        .post_init(post_init)
        .build()
    )

    app.add_handler(
        CommandHandler(
            "start",
            start,
        )
    )

    app.add_handler(
        CommandHandler(
            "cancel",
            cancel,
        )
    )

    app.add_handler(
        CommandHandler(
            "back",
            back,
        )
    )

    app.add_handler(
        CommandHandler(
            "menu",
            back,
        )
    )

    app.add_handler(
        CallbackQueryHandler(
            on_callback
        )
    )

    app.add_handler(
        MessageHandler(
            (
                filters.TEXT
                | filters.PHOTO
            )
            & ~filters.COMMAND,
            on_message,
        )
    )

    app.add_error_handler(
        on_error
    )

    if app.job_queue:
        app.job_queue.run_repeating(
            poll_pending_orders,
            interval=120,
            first=60,
        )

    return app


def main():
    app = build_app()

    logger.info(
        "Starting Ball Supplies bot..."
    )

    app.run_polling(
        allowed_updates=Update.ALL_TYPES,
        drop_pending_updates=True,
    )


if __name__ == "__main__":
    main()
